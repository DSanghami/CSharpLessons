﻿using System.Data.SqlClient;
using System.Data;

namespace FirstMVCapp.Models
{
    
        public class MovieRepository
        {
            public static List<Movies> GetMovieList()
            {
                // These are null methods. We use this if we dont want to override all the methods only want to read particular number of methods.
                List<Movies> empList = new List<Movies>();
                using (SqlConnection cn = SqlHelper.CreateConnection())
                {
                    if (cn.State != ConnectionState.Open)
                    {
                        cn.Open();
                    }
                    SqlCommand selectmoviecmd = cn.CreateCommand();
                    String selectAllMovies = "Select * from Movies";
                    selectmoviecmd.CommandText = selectAllMovies;
                    SqlDataReader empdr = selectmoviecmd.ExecuteReader();
                    while (empdr.Read())
                    {
                        Movies emp = new Movies
                        {
                            Id = empdr.GetInt32(0),
                            Title = empdr.GetString(1),
                            Language = empdr.GetString(2),

                            Hero = empdr.GetString(3),
                            Director = empdr.GetString(4),
                            MusicDirector = empdr.GetString(5),
                            ReleaseDate = empdr.GetDateTime(6),
                            Cost = empdr.GetDecimal(7),
                            Collection = empdr.GetDecimal(8),
                            Review = empdr.GetString(9),


                        };
                        empList.Add(emp);
                    }
                    return empList;

                }
                return null;
            }
        public static Movies GetMoviesById(int id)
        {
            Movies moviesFound = null;
            using (SqlConnection cn = SqlHelper.CreateConnection())
            {
                if (cn.State != System.Data.ConnectionState.Open)
                    cn.Open();
                SqlCommand selectmoviescmd = cn.CreateCommand();
                String selectMovies = "Select * from Movies where ID=@id";
                selectmoviescmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                selectmoviescmd.CommandText = selectMovies;
                SqlDataReader moviedr = selectmoviescmd.ExecuteReader();
                while (moviedr.Read())
                {
                    moviesFound = new Movies
                    {
                        Id = moviedr.GetInt32(0),
                        Title = moviedr.GetString(1),
                        Language = moviedr.GetString(2),

                        Hero = moviedr.GetString(3),
                        Director = moviedr.GetString(4),
                        MusicDirector = moviedr.GetString(5),
                        ReleaseDate = moviedr.GetDateTime(6),
                        Cost = moviedr.GetDecimal(7),
                        Collection = moviedr.GetDecimal(8),
                        Review = moviedr.GetString(9),
                    };
                }
            }
            return moviesFound;
        }
    }
    }  
